Save this directory as 'DatasetName.tar.gz' and use it in the next phase.
